<?php
include "Crud.php";

require_once "DBConnector.php";

class User implements Crud{
	private $user_id;
	private $first_name;
	private $last_name;
	private $city;


	public function setId($user_id){
		$this->user_id=$user_id;
	}
	public function getId(){
		return $this->$user_id;
	}

	public function save(){
		$con= new DBConnect();
		$fn=$this->first_name;
		$ln=$this->last_name;
		$ct=$this->city;
		$sql="INSERT INTO user(first_name,last_name,user_city) VALUES ('$fn','$ln','$ct')";
		$res=mysqli_query($con->conn,$sql);
		return $res;
	}
	public function readUnique(){
		return null;
	}
	public function readAll(){
		return null;
	}
	public function search(){
		return null;
	}
	public function update(){
		return null;
	}
	public function removeOne(){
		return null;
	}
	public function removeAll(){
		return null;
	}
}
?>