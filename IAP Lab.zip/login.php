<?php

include "DBConnector.php";
include "User.php";

$con=new DBConnect();

if(isset($_POST['btn-login'])){
	$username=$_POST['username'];
	$password=$_POST['password'];
	$instance=User::create();
	$instance->setPassword($password);
	$instance->setUsername($username);

	if($instance->isPasswordCorrect()){
		$instance->login();
		$con->closeDatabase();
		$instance->createUserSession();
	}else{
		$con->closeDatabase();
		header("Location: login.php");
	}
}

?>

<html>
<head>
	<title>Login Details</title>
</head>
<body>
	<form type="POST" name="login" id="login" action="<?php $_SERVER['PHP_SELF']?>">
	<table align="center">
		<tr>
			<td><input type="text" name="username" placeholder="Username"></td>
		</tr>
		<tr>
			<td><input type="password" name="password" placeholder="Password"></td>
		</tr>
		<tr>
			<td><button type="submit" name="btn-login"><strong>Login</strong></button></td>
		</tr>
	</table>
</form>
</body>
</html>